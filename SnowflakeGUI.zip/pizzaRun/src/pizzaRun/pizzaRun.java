package pizzaRun;
/*
 * pizzaRun.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */
//No CVS due to lack of access.

import java.text.*;
import java.text.*;
import java.util.*;

/**
 * @author Suhail Prasathong
 *
 */
public class pizzaRun {

	/**
	 * @param args
	 */
	private static final int SLICE_PER_PIZZA = 8;
	public static void main(String[] args) 
	
	{
		int allSlice;
		double PizCost;
		Scanner in= new Scanner(System.in);
		NumberFormat form = new DecimalFormat("0.00");
		System.out.println("Total cost of Pizza: ");
		//ask user total cost of pizza
		
		PizCost=in.nextDouble();
		System.out.println("How many total Slices do you need?");
		allSlice=in.nextInt();
		int numPies=calcuAllPizza(allSlice);
		//ask amount of slices
		
		System.out.println("Buy "+numPies+" $"+(numPies*PizCost));
		
		System.out.println("There will be "
		+((numPies*SLICE_PER_PIZZA)-allSlice) 
		+ " slice left");
		
	}
	
	public static int calcuAllPizza(int Slices)
	{
		int num=Slices%SLICE_PER_PIZZA ;
		return num;
	} //main
} //class pizzaRun close