/*
 * PrimeSieve.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */

//NO CVS DUE TO LACK OF ACCESS.
import java.util.*;
import java.*;

/**
 * StyleExample serves as an example of recommended Java coding style.
 *
 * @author sxp9646 (Suhail Prasathong)
 * I do not have a CS login ID yet.
 */


public class PrimeSieve {

	/**
	 * @param args
	 */
	
	public static ArrayList<Integer> findPrimes(int N) {
    
        return findPrimes(0);
    } 
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		ArrayList<Integer> primes = new ArrayList<Integer>();
        ArrayList<Integer> list = new ArrayList<Integer>();
		System.out.println("Compute prime numbers from 2 to: ");
		
		int input = in.nextInt();
		
		for(int i=2; i<input; i++){
			list.add(i);
		}
		
		
	}   // main()
}   // PrimeSieve{}