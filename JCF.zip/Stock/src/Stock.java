/**
 * File:
 *   $Id: Stock.java,v 1.1 2014/10/01 03:32:36 sxp9646 Exp $
 *   
 * Revisions:
 *   $Log: Stock.java,v $
 *   Revision 1.1  2014/10/01 03:32:36  sxp9646
 *   *** empty log message ***
 *
 */

//imports go here.

/**
 * Stock.java
 * Implementation of the Stock class.  This class implements
 * various methods that the Brokerage class can call and implement.
 * 
 * @author sxp9646: Suhail Prasathong 
 *
 */


public class Stock {



	private String name;
	private int stockPrice;
	private int shares;

	/**
	 * Stock constructor.
	 *return: none
	 *param: none
	 */

	public Stock() {
		this("nothing", 0, 5);
	}

	/**
	 * Stock constructor.
	 *return: none
	 *param: none
	 */

	public Stock(String name, int stockPrice, int shares) {
		this.name = name;
		this.stockPrice = stockPrice;
		this.shares = shares;
	}

	/**
	 * plusGet constructor used to add shares.
	 *return: none
	 *param: none
	 */

	public void plusGet(int newShares) {

		this.shares += newShares;
	}

	/**
	 * getName method. Used to access name.
	 *return: name.
	 *param: none
	 */

	public String getName() {
		return name;
	}

	/**
	 * getStockPrice method. Used to access stockPrice.
	 *return: stockPrice.
	 *param: none
	 */

	public int getStockPrice() {
		return stockPrice;
	}
	
	/**
	 * setStockPrice method. Used to set stockPrice.
	 *return: name.
	 *param: none
	 */

	public void setStockPrice(int stockPrice) {
		this.stockPrice = stockPrice;
	}
	
	/**
	 * getShares method. Used to accesses shares.
	 *return: shares.
	 *param: none
	 */


	public int getShares() {
		return shares;
	}
	
	/**
	 * setShares method. Used to setup shares.
	 *return: none.
	 *param: none
	 */

	public void setShares(int shares) {
		this.shares = shares;
	}
	
	/**
	 * setShares method. Used to access value.
	 *return: none.
	 *param: none
	 */

	public int getValue(){
		return this.shares*this.stockPrice;
	}
	
	/**
	 * equals method. Used to compare names.
	 *return: result.
	 *param: Object extra
	 */

	@Override
	public boolean equals(Object extra) {
		boolean result = false;
		if(extra instanceof Stock)
		{
			Stock s= (Stock) extra;
			if(this.name.equals(s.name)) {
				result=true;
			}
		}
		return result;
	}

}
