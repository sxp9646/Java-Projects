/**
 * File:
 *   $Id: Name.java,v 1.1 2014/10/01 03:32:37 sxp9646 Exp $
 *   
 * Revisions:
 *   $Log: Name.java,v $
 *   Revision 1.1  2014/10/01 03:32:37  sxp9646
 *   *** empty log message ***
 *
 */

import java.util.Comparator;

/**
 * Name.java
 * Implementation of the name class.  This class compares names.
 * 
 * @author sxp9646: Suhail Prasathong 
 *
 */


public class Name implements Comparator<Stock> {

	@Override
	public int compare(Stock stock, Stock other) {
		return stock.getName().compareTo(other.getName());
	}

}
