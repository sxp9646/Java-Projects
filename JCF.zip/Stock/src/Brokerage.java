/**
 * File:
 *   $Id: Brokerage.java,v 1.1 2014/10/01 03:32:37 sxp9646 Exp $
 *   
 * Revisions:
 *   $Log: Brokerage.java,v $
 *   Revision 1.1  2014/10/01 03:32:37  sxp9646
 *   *** empty log message ***
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;


/**
 * Implementation of the Brokerage class.  In this simplified simulation
 * the brokerage will manage a single client's investments.  It will
 * also track the movement of the market as a whole.
 * 
 * @author atd: Aaron T Deever
 * @author sxp9646: Suhail Prasathong 
 *
 */
public class Brokerage {

	/* Map containing stocks available and their current price per share.
	 */
	private Map<String, Integer> market = 
			new HashMap<String, Integer>();
	int allInvestment;
	private ArrayList<Stock> ar = new ArrayList<Stock>();
	
	
	


	/**
	 * Constructor.  Initializes the investor and the market as a whole.
	 * In this simplified simulation there is just a single investor and the
	 * whole market is tracked by the brokerage.
	 * @param initialInvestment initial investment
	 */
	public Brokerage(int initialInvestment) { 
		this.allInvestment = initialInvestment;
		/* initialize the market */
		market.put("GOOG", 1183);
		market.put("AMZN", 360);
		market.put("AAPL", 532);
		market.put("YHOO", 38);
		market.put("MSFT", 40);
		market.put("EBAY", 57);
	}

	/**
	 * Add to Investor's holding.  This function should error-check to 
	 * ensure the ticker symbol exists, the number of shares requested
	 * is a positive value, and that the client has sufficient funds.
	 * @param tickerSymbol the particular stock to buy
	 * @param shares the number of shares requested
	 * @return true if transaction is completed.  False otherwise.
	 */
	public boolean increaseHolding(String tickerSymbol, int shares) { 
		boolean result = false;
		{ 

			if(market.containsKey(tickerSymbol)) {
				if(shares > 0){
					if(shares*market.get(tickerSymbol) < allInvestment){
						Stock st = new Stock(tickerSymbol,market.get(tickerSymbol), market.get(shares));
						if(ar.contains(st)){
							for(Stock a:ar) {
								if (a.equals(st)){
									a.plusGet(shares);
									result=true;
									this.allInvestment-=market.get(tickerSymbol)*shares;
								}
								else
								{
									ar.add(st);
									result=true;
									this.allInvestment-=market.get(tickerSymbol)*shares;        
								}	
							}
						}
					}
				}
			}
		}
		return result;
	}

	/**
	 * Reduce Investor's holding.  This function should error-check to 
	 * ensure the ticker symbol exists, and the number of shares to reduce
	 * is a positive value no greater than the number currently held.
	 * @param tickerSymbol the particular stock to sell
	 * @param shares the number of shares to sell
	 * @return true if transaction is completed.  False otherwise.
	 */
	public boolean reduceHolding(String tickerSymbol, int shares) { 

		boolean result=false;
		if (market.containsKey(tickerSymbol)){
			int locator=0;
			for (int i=0;i< ar.size();i++){
				if (ar.get(i).equals(tickerSymbol)){
					locator=i;
				}
			}
			if (shares>0&& shares<=ar.get(locator).getShares()){
				if (shares==ar.get(locator).getShares()){
					ar.remove(locator);
					result=true;
				}
				else{
					ar.get(locator).plusGet(-shares);
					this.allInvestment+=shares*ar.get(locator).getStockPrice();
					result=true;
				}
			}
		}
		return result;
	}

	/**
	 * Generates a string to represent the investor's portfolio.  Can be
	 * requested in alphabetical order, or in decreasing order of the
	 * value of the holdings (shares * price per share).
	 * @param choice "N" for by name, "V" for by value
	 * @return String representing the portfolio.  This string must
	 * include the name, number of shares, price per share, and total 
	 * value for each stock in the portfolio.  The entries must be
	 * sorted according to the input request.
	 */
	public String accessPortfolio(String choice){ 
		String x="";
		x+="CURRENT PORTFOLIO\n";
		x+="Cash Available: 5535\n";
		x+="SYMBOL SHARES PRICE TOTAL VALUE\n";
		x+="===============================\n";
		//x+=String.format("%6d", whats getting printed out)
		if (choice.equals("N")){
			//ar.sort(new Name());
		}
		else if (choice=="V"){
			System.out.println("Y");
			//ar.sort(new Value());
		}
		for (int i=0; i< ar.size();i++){
			x+="  " + ar.get(i).getName();
			x+= String.format("%6d",ar.get(i).getShares());
			x+= String.format("%7d",ar.get(i).getStockPrice());
			x+= String.format("%11d",ar.get(i).getValue());
			x+="\n";
		}
		return x;
	}



	/**
	 * Update the price per share of each stock using a random value to
	 * determine the change.  A multiplier is applied to the stock price and
	 * the result is rounded to the nearest integer.  A minimum price of $1 is
	 * required. (For the given inputs, this constraint will always hold
	 * without checking). This method can also be used to update the price of
	 * a stock inside any stock object that contains that information.
	 * @return A string "ticker" that indicates
	 *         the ticker symbols and their prices.
	 */
	public String tickerUpdate() { 

		String output = "";

		for(String str : market.keySet()) { 
			int statValue = market.get(str);
			double num = (Math.random()*2.5);
			int newValue;
			double val;
			val= (statValue * num);
			newValue = (int)val;
			if (newValue<1) newValue+=1;
			
			market.put(str,  newValue);
			output += str + " " + newValue + "      ";
			System.out.println("NEWVALUE: "+newValue);
			for (int i=0;i<ar.size();i++){
				
			}
		}

		return output;
	}

	/**
	 * Sell all remaining stocks in the portfolio.
	 * @return the cash value of the portfolio.
	 */
	public int closeAccount() { 
		for (int i=0;i<ar.size();i++){
			Stock stk=ar.remove(i);
			this.allInvestment+=stk.getShares()*stk.getStockPrice();
		}
			
		
		return this.allInvestment ;
	}
}