/**
 * File:
 *   $Id: Value.java,v 1.1 2014/10/01 03:32:37 sxp9646 Exp $
 *   
 * Revisions:
 *   $Log: Value.java,v $
 *   Revision 1.1  2014/10/01 03:32:37  sxp9646
 *   *** empty log message ***
 *
 */

import java.util.Comparator;

/**
 * Value.java
 * This class compares values.
 * 
 * @author sxp9646: Suhail Prasathong 
 *
 */

public class Value implements Comparator<Stock> {

	@Override
	public int compare(Stock stock, Stock alternate) {
		return stock.getValue()-alternate.getValue();
		
	}

}
