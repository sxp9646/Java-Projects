/*
 * MazeSearch.java
 *
 * Version:
 * $Id: MazeSearch.java,v 1.1 2014/10/22 00:23:56 sxp9646 Exp $
 *
 * Revisions:
 * $Log: MazeSearch.java,v $
 * Revision 1.1  2014/10/22 00:23:56  sxp9646
 * *** empty log message ***
 *
 */

import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

/**
 * MazeSearch class is simulation engine for building and searching a graph
 * using stack-based DFS and queue-based BFS.
 * 
 * @author atd Aaron T Deever
 * modified by: sxp9646 Suhail Prasathong
 *
 */
public class MazeSearch {

	/*
	 * The two types of graph searching we will use
	 */
	public enum SearchType {
		DFS,
		BFS
	}

	/**
	 * Main driver prompts for the name of a graph file, builds the graph,
	 * prompts for a start and finish node name, and prints a resulting path.
	 * 
	 * @param args not used
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter graph data filename: ");
		String filename = in.next();
		Maze g = new Maze(filename);

		System.out.print(g);

		// repeatedly perform either DFS (stack) or BFS (queue) on the graph
		while(true) { 

			// prompt for name of start and finish nodes
			System.out.print("Enter starting node name: ");
			String start = in.next();
			if(!g.isInGraph(start)) { 
				System.out.println(start + " is not a valid node in the graph.");
				continue;
			}

			System.out.print("Enter finishing node name: ");
			String finish = in.next();
			if(!g.isInGraph(finish)) { 
				System.out.println(finish + " is not a valid node in the graph.");
				continue;
			}

			System.out.println("Checking for path existence...");
			boolean found = g.canReachDFS(start, finish);
			if (found) {
				System.out.println("Path exists? True");
			} else {
				System.out.println("Path exists? False");
			}

			
			if(found){
				List<Node> path = null;
				List<Node> otherPath = null;
				
				path = g.searchDFS(start, finish);
				otherPath = g.searchBFS(start, finish);
			
			//Implement BFS to find node, use DFS to print any path, 
			//Print shortest path using BFS
			//find if path exists graph.

				if(path.isEmpty()) { 
					System.out.println("Path exists?");
				}
				else if(path.size() == 1) { 
					System.out.println("You are already there!");
				}
				else { 
					System.out.println("Any Path: "+ path.size() + " hops: ");
					for(int n=0; n < path.size()-1; n++) { 
						System.out.println(path.get(n).getName() + " to " + 
								path.get(n+1).getName());
					}
					
					System.out.println("Shortest path: " + otherPath.size() + " hops: ");
					for(int i=0; i<otherPath.size()-1; i++) {
						System.out.println(otherPath.get(i).getName() + 
								"to " + otherPath.get(i+1).getName());
						
					}
					
					in.close();
					return;
				}
			}
		}

	}
}
