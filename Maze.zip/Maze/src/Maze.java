/*
 * Maze.java
 *
 * Version:
 * $Id: Maze.java,v 1.1 2014/10/22 00:23:56 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Maze.java,v $
 * Revision 1.1  2014/10/22 00:23:56  sxp9646
 * *** empty log message ***
 *
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;

/**
 * Maze class. Holds representation of a graph as well as functions to 
 * interact with the graph.
 * 
 * @author atd Aaron T Deever
 * @author sps Sean Strout
 * @author sxp Suhail Prasathong (Modified)
 *
 */
public class Maze {

	/*
	 * graph is represented using a map (dictionary).
	 */
	private Map<String, Node> graph;

	/**
	 * Constructor.  Loads graph from a given filename.  Assumes that each line
	 * in the input file contains the names of two nodes.  Creates nodes
	 * as necessary as well as undirected edges between the nodes.
	 * Returns the graph in the form of a map having the names of the
	 * nodes as keys, and the nodes themselves as values.
	 * 
	 * @param filename
	 */
	public Maze(String filename) throws FileNotFoundException { 

		// open the file for scanning
		File file = new File(filename);
		Scanner in = new Scanner(file);


		// create the graph
		graph = new HashMap<String, Node>();

		// loop over and parse each line in the input file

		// read and split the line into an array of strings
		// where each string is separated by a space.
		Node n1, n2;
		String line = in.nextLine();
		String[] fields = line.split(" ");
		String rs="",cs="";
		if(fields.length == 2){
			rs=fields[0];
			cs=fields[1];
		}			
		int r=Integer.parseInt(rs);
		int c=Integer.parseInt(cs);					
		for(int y=1; y<=r; y++){
			for(int x=1; x<=c; x++){
				String key = ((y-1)+","+(x-1));
				graph.put(key, new Node(key));
			}			
		}
		int counterlen = 0;
		int counterwid=0;
		int counter = 0;
		int counterlen2=0;
		int counterwid2=0;

		while(in.hasNextLine()){
			String l = in.nextLine();

			if(counter%2==0){ 	//lines with nodes
				String[] ls = l.split(" ");
				counterwid=0;
				for(int i=1; i< ls.length; i+=2){
					//System.out.print(ls[i]);
					if(ls[i].contains(".")){
						String node1= counterlen+","+(counterwid);
						String node2= (counterlen)+","+(counterwid+1);
						graph.get(node1).addNeighbor(graph.get(node2));
						graph.get(node2).addNeighbor(graph.get(node1));

						//System.out.print(node1+" neighbors "+node2);
						counterwid++;							
					}
					else{
						counterwid++;
					}
				}
				counterlen++;
			}



			else{ 				//lines with neighbors only
				String[] ls = l.split("   ");
				counterwid2=0;
				for(int i=0; i< ls.length; i++){

					//System.out.print(ls[i]+"    ");
					//System.out.print(ls[i].contains(".")+"\t");
					if(ls[i].contains(".")){
						//System.out.print(ls[i]);
						String node1=counterlen2+","+counterwid2;
						String node2=(counterlen2+1)+","+counterwid2;
						//System.out.println(node1+" neighbors "+node2);
						graph.get(node1).addNeighbor(graph.get(node2));
						graph.get(node2).addNeighbor(graph.get(node1));
						counterwid2++;
					}
					else{
						counterwid2++;
					}
				}	
				counterlen2++;
				System.out.println();
			}

			counter++;
		}

		in.close();
	}

	/**
	 * Method to generate a string associated with the graph.  The string
	 * comprises one line for each node in the graph. Overrides
	 * Object toString method.
	 * 
	 * @return string associated with the graph.
	 */
	public String toString() { 
		String result = "";
		for (String name : graph.keySet()) { 
			result = result + graph.get(name) + "\n";
		}
		return result;
	}

	/**
	 * Method to check if a given String node is in the graph.
	 * @param nodeName: string name of a node
	 * @return boolean true if the graph contains that key; false otherwise
	 */
	public boolean isInGraph(String nodeName) { 
		return graph.containsKey(nodeName);
	}

	/**
	 * For a given start and finish node, we simply want to know whether
	 * a path exists, or not, between them. This is the precursor to 
	 * searchDFS().
	 * @param start the name associated with the node from which to start the search
	 * @param finish the name associated with the destination node	 
	 * @return boolean true if a path exists; false otherwise
	 */
	public boolean canReachDFS(String start, String finish) {
		// assumes input check occurs previously
		Node startNode, finishNode;
		startNode = graph.get(start);
		finishNode = graph.get(finish);

		// prime the stack with the starting node
		Stack<Node> stack = new Stack<Node>();
		stack.push(startNode);

		// create a visited set to prevent cycles
		Set<Node> visited = new HashSet<Node>();
		// add start node to it
		visited.add(startNode);

		// loop until either the finish node is found (path exists), or the 
		// dispenser is empty (no path)
		while (!stack.isEmpty()) { 
			Node current = stack.pop();
			if (current == finishNode) {
				return true;    
			}
			// loop over all neighbors of current
			for (Node nbr : current.getNeighbors()) { 
				// process unvisited neighbors
				if (!visited.contains(nbr)) {
					visited.add(nbr);
					stack.push(nbr);
				}
			}
		}
		return false;
	}

	/**
	 * Method that visits all nodes reachable from the given starting node
	 * in depth-first search fashion using a stack, stopping only if the finishing
	 * node is reached or the search is exhausted.  A predecessors map
	 * keeps track of which nodes have been visited and along what path
	 * they were first reached.
	 * 
	 * @param start the name associated with the node from which to start the search
	 * @param finish the name associated with the destination node
	 * @return path the path from start to finish.  Empty if there is no such path.
	 * 
	 * Precondition: the inputs correspond to nodes in the graph. 
	 */
	public List<Node> searchDFS(String start, String finish) { 

		// assumes input check occurs previously
		Node startNode, finishNode;
		startNode = graph.get(start);
		finishNode = graph.get(finish);

		// prime the dispenser (stack) with the starting node
		List<Node> dispenser = new LinkedList<Node>();
		dispenser.add(0, startNode);

		// construct the predecessors data structure
		Map<Node, Node> predecessors = new HashMap<Node,Node>();
		// put the starting node in, and just assign itself as predecessor
		predecessors.put(startNode, startNode);

		// loop until either the finish node is found, or the 
		// dispenser is empty (no path)
		while (!dispenser.isEmpty()) { 
			Node current = dispenser.remove(0); 
			if (current == finishNode) {
				break;
			}
			// loop over all neighbors of current
			for (Node nbr : current.getNeighbors()) { 
				// process unvisited neighbors
				if(!predecessors.containsKey(nbr)) { 
					predecessors.put(nbr, current);
					dispenser.add(0, nbr);
				}
			}
		}

		return constructPath(predecessors, startNode, finishNode);
	}

	/**
	 * Method that visits all nodes reachable from the given starting node
	 * in breadth-first search fashion using a queue, stopping only if the finishing
	 * node is reached or the search is exhausted.  A predecessors map
	 * keeps track of which nodes have been visited and along what path
	 * they were first reached.
	 * 
	 * @param start the name associated with the node from which to start the search
	 * @param finish the name associated with the destination node
	 * @return path the path from start to finish.  Empty if there is no such path.
	 * 
	 * Precondition: the inputs correspond to nodes in the graph. 
	 */
	public List<Node> searchBFS(String start, String finish) { 

		// assumes input check occurs previously
		Node startNode, finishNode;
		startNode = graph.get(start);
		finishNode = graph.get(finish);

		// prime the dispenser (queue) with the starting node
		List<Node> dispenser = new LinkedList<Node>();
		dispenser.add(startNode);

		// construct the predecessors data structure
		Map<Node, Node> predecessors = new HashMap<Node,Node>();
		// put the starting node in, and just assign itself as predecessor
		predecessors.put(startNode, startNode);

		// loop until either the finish node is found, or the 
		// dispenser is empty (no path)
		while (!dispenser.isEmpty()) { 
			Node current = dispenser.remove(0);
			if (current == finishNode) {
				break;
			}
			// loop over all neighbors of current
			for (Node nbr : current.getNeighbors()) { 
				// process unvisited neighbors
				if(!predecessors.containsKey(nbr)) { 
					predecessors.put(nbr, current);
					dispenser.add(nbr);
				}
			}
		}

		return constructPath(predecessors, startNode, finishNode);
	}


	/**
	 * Method to return a path from the starting to finishing node.
	 * 
	 * @param predecessors Map used to reconstruct the path
	 * @param startNode starting node
	 * @param finishNode finishing node
	 * @return a list containing the sequence of nodes comprising the path.
	 * Empty if no path exists.
	 */
	private List<Node> constructPath(Map<Node,Node> predecessors,
			Node startNode, Node finishNode) { 

		// use predecessors to work backwards from finish to start, 
		// all the while dumping everything into a linked list
		List<Node> path = new LinkedList<Node>();

		if(predecessors.containsKey(finishNode)) { 
			Node currNode = finishNode;
			while (currNode != startNode) { 
				path.add(0, currNode);
				currNode = predecessors.get(currNode);
			}	
			path.add(0, startNode);
		}

		return path;
	}
}