/*
 * Snowflake.java
 *
 * Version:
 * $Id$
 *
 * Revisions:
 * $Log$
 */

//NO CVS DUE TO LACK OF ACCESS.
import java.util.Scanner;

/**
 * StyleExample serves as an example of recommended Java coding style.
 *
 * @author sxp9646 (Suhail Prasathong)
 * I do not have a CS login ID yet.
 */

public class Snowflake extends java.lang.Object {
	

	/**
	 * @param args
	 */
	
	public static Turtle init(int S){
		Turtle t = new Turtle (0.5,0.5,0);
		
		return t; //stubbed for development
	} //end of method
	
	public static void snowflake(double S, int N, Turtle t){
		for(int i=0; i<6; i++){
			snowflakeSide(S,N,t);
			t.turnLeft(60);
		
		}
			
	} //end of method
	
	public static void snowflakeSide(double S, int N, Turtle t){
		if (N>0) {
			t.goForward(S);
			if (N>1){
				t.turnLeft(120);
				for(int i=0; i<5; i++){
					snowflakeSide(S/3,N-1, t);
					t.turnRight(60);
				}
				
				t.turnRight(180);
			}
			
			t.goForward(-S);
		}

	} //end of method
	
	/**
     * main method, executes the program.
     * questions user for input
     * @param    args      command line arguments -- unused
     */
	
	public static void main(String[] args) 
	{

		Scanner in = new Scanner(System.in);
		System.out.println("Enter number of lines: ");
		double s = in.nextDouble();
		System.out.println("Enter number of branches: ");
		int n = in.nextInt();
		
		Turtle t = init(100);
		snowflake(s,n,t);
	} // main
		
} //class Snowflake
