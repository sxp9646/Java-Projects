package Players.SXP9646;
/*
 * SXP9646.java
 *
 * Version:
 * $Id: SXP9646.java,v 1.1 2014/10/15 03:24:38 sxp9646 Exp $
 *
 * Revisions:
 * $Log: SXP9646.java,v $
 * Revision 1.1  2014/10/15 03:24:38  sxp9646
 * *** empty log message ***
 *
 */
import Interface.Coordinate;
import Engine.Logger;
import Interface.GobbletPart1;
import Interface.PlayerModule;
import Interface.PlayerMove;

import java.util.ArrayList;
import java.util.Stack;

// imports go here, if any.

/**
 * SXP9646 serves as the whole and sole operator class of the game.
 *
 * @author Suhail Prasathong SXP9646
 */


public class SXP9646 implements PlayerModule, GobbletPart1{

	private Stack<Piece>[][] board;
	private Stack<Piece>[] p1Pieces;
	private Stack<Piece>[] p2Pieces;
	private int id;
	private Logger log;
	
/**
* PlayerMove hosts arraylist of moves. 
* @param    none
* @return   moves
*/
	
	@Override
	public PlayerMove move(){
		ArrayList<PlayerMove> moves = validNextMoves(this.getID());
		return moves.get(0);
	}

/**
* playerInvalidated sets argument parameters. 
* @param    arg0
* @return   moves
*/
	
	@Override
	public void playerInvalidated(int arg0){
		// TODO Auto-generated method stub

	}
	
/**
* dumbGameState works as a cursory safety method. 
* @param    various
* @return   id
*/

	public void dumpGameState(){
		for (int i = 0; i < board.length; i++){
			for (int j = 0; j < board.length; j++){
				if (board[i][j].isEmpty()){
					System.out.print(" []  ");
				}
				else{
					System.out.print(board[i][j].peek() + " ");
				}
			}
			if (i == 0){
				System.out.print("  ");
				for (int k = 0; k < p1Pieces.length; k++){
					if (p1Pieces[k].isEmpty()){
						System.out.print("_ ");
					}
					else{
						System.out.print(p1Pieces[k].peek().getSize() + " ");
					}
				}
			}
			else if (i == 2){
				System.out.print("  ");
				for (int k = 0; k < p2Pieces.length; k++){
					if (p2Pieces[k].isEmpty()){
						System.out.print("_ ");
					}
					else{
						System.out.print(p2Pieces[k].peek().getSize() + " ");
					}
				}
			}
			System.out.println();
		}
	}
	
/**
* getId gets ID. 
* @param    
* @return   ID
*/

	public int getID(){
		return id;
	}
	
/**
* getTopOwnerOnBoard gets the top piece on the board. 
* @param    row, col
* @return   -1
*/

	public int getTopOwnerOnBoard(int row, int col){
		if (board[row][col].isEmpty()){
			return -1;
		}
		else{
			return board[row][col].peek().getId();
		}
	}
	
/**
* getTopSizeOnBoard gets largest size on board. 
* @param    row col
* @return   -1
*/

	public int getTopSizeOnBoard(int row, int col){
		if (board[row][col].isEmpty()){
			return -1;
		}
		else{
			return board[row][col].peek().getSize();
		}
	}
	
/**
* getTopSizeOnStack sets argument parameters. 
* @param    pId, stackNum
* @return   -1
*/

	public int getTopSizeOnStack(int pId, int stackNum){
		if (pId == 1){
			if (p1Pieces[stackNum-1].isEmpty()){
				return -1;
			}
			else{
				return p1Pieces[stackNum-1].peek().getSize();
			}
		}
		else{
			if (p2Pieces[stackNum-1].isEmpty()){
				return -1;
			}
			else{
				return p2Pieces[stackNum-1].peek().getSize();
			}
		}
	}
	
/**
* init initializes the double array. 
* @param    logger, playerId
* @return   
*/

	public void init(Logger logger, int playerId){
		id = playerId;
		log = logger;
		board = new Stack[4][4];
		for (int i = 0; i < board.length; i++){
			for (int j = 0; j < board.length; j++){
				board[i][j] = new Stack<Piece>();
			}
		}

		p1Pieces = new Stack[3];
		p2Pieces = new Stack[3];
		for (int i = 0; i < p1Pieces.length; i++){
			p1Pieces[i] = new Stack<Piece>();
			p2Pieces[i] = new Stack<Piece>();
			for (int j = 1; j <= 4; j++){
				p1Pieces[i].push(new Piece(1, j));
				p2Pieces[i].push(new Piece(2, j));
			}
		}
	}

/**
* Arraylist creates an arraylist to host pieces. 
* @param    player
* @return   moves
*/
	
	public ArrayList<PlayerMove> validNextMoves(int player){
		Stack<Piece>[] thesePieces;
		ArrayList<PlayerMove> moves = new ArrayList<PlayerMove>();
		if (player == 1){
			thesePieces = p1Pieces;
		}
		else{
			thesePieces = p2Pieces;
		}

		for (int s = 0; s < 3; s++){
			if (thesePieces[s].isEmpty()){
				continue;
			}
			else{
				for (int row = 0; row < board.length; row++){
					for (int col = 0; col < board.length; col++){
						if (!board[row][col].isEmpty()){
							continue;
						}
						else{
							moves.add(new PlayerMove(player, s+1, thesePieces[s].peek().getSize(), new Coordinate(-1, -1), new Coordinate(row, col)));
						}
					}
				}
			}
		}
		for (int row = 0; row < board.length; row++){
			for (int col = 0; col < board.length; col++){
				if (board[row][col].isEmpty()){
					continue;
				}
				else if (board[row][col].peek().getId() == player){
					for (int r = 0; r < board.length; r++){
						for (int c = 0; c < board.length; c++){
							if (!board[r][c].isEmpty()){
								if (board[row][col].peek().getSize() > board[r][c].peek().getSize()){
									moves.add(new PlayerMove(player, 0, board[row][col].peek().getSize(), new Coordinate(row, col), new Coordinate(r, c)));
								}
							}
							else{
								moves.add(new PlayerMove(player, 0, board[row][col].peek().getSize(), new Coordinate(row, col), new Coordinate(r, c)));
							}
						}
					}
				}
			}
		}
		return moves;
	}
	
/**
* lastMove dictates the last move made by a player. 
* @param    move
* @return   
*/
	
	public void lastMove(PlayerMove move){
		if (move.getStack() == 0){
			Piece temp = board[move.getStartRow()][move.getStartCol()].pop();
			board[move.getEndRow()][move.getEndCol()].push(temp);
		}
		else if (move.getPlayerId() == 1){
			Piece temp = p1Pieces[move.getStack()-1].pop();
			board[move.getEndRow()][move.getEndCol()].push(temp);
		}
		else if (move.getPlayerId() == 2){
			Piece temp = p2Pieces[move.getStack()-1].pop();
			board[move.getEndRow()][move.getEndCol()].push(temp);
		}
	}

} //End Class SXP9646