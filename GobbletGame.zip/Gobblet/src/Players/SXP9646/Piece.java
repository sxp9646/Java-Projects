package Players.SXP9646;

/*
 * SXP9646.java
 *
 * Version:
 * $Id: Piece.java,v 1.1 2014/10/15 03:24:38 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Piece.java,v $
 * Revision 1.1  2014/10/15 03:24:38  sxp9646
 * *** empty log message ***
 *
 */

/**
 * Piece serves the class that defines the 
 * operations of a piece in the game including its 
 * size player1/2 etc.
 *
 * @author Suhail Prasathong SXP9646
 */

public class Piece {
	private int id;
	private int size;
	
/**
* Piece illustrates initial location of piece. 
* @param    none
* @return   origin
*/
	
	public Piece(){ 
		this(0,0);
	}
	
/**
* Piece illustrates initial location of piece. 
* @param    int id, int size
* @return   id and size
*/
	
	public Piece(int id,int size){
		this.id=id;
		this.size=size;
	}
	public int getId(){
		return this.id;
	}
	public int getSize(){
		return this.size;
	}
	
/**
* toString returns string. 
* @param    none
* @return   a string
*/
	
	@Override
	public String toString(){
		
		return this.size+"("+this.id+")";
	}
	
} //End Piece class