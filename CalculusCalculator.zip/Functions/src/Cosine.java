/*
 * Cosine.java
 *
 * Version:
 * $Id: Cosine.java,v 1.1 2014/10/08 03:05:11 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Cosine.java,v $
 * Revision 1.1  2014/10/08 03:05:11  sxp9646
 * *** empty log message ***
 *
 */


/**
 * Cosine class serves to operate the derivative and
 * integral perspectives of the cosine function in general
 * mathematics. 
 *
 * @author Suhail Prasathong sxp9646
 */
public class Cosine extends Function {
	private Function Argument;
	
/**
* Cosine takes in the cosine argument. 
* @param    a
* @return   none
*/
	public Cosine (Function a) {
		Argument = a;
	}
	
/**
* Derivative illustrates the derivative of a constant. 
* @param    none
* @return   result. 
*/
	
	public Function derivative() {
		Function a = new Sine(Argument);
		Function result = new Product( a, Argument.derivative(), new Constant(-1) );
		return result;
	}
	
/**
* Evaluate illustrates the integral of a double. 
* @param    none
* @return   Math.cos(Argument.evaluate(x));
*/
	
	public double evaluate(double x) {
		return Math.cos(Argument.evaluate(x));
	}
	
/**
* isConstant illustrates a constant value. 
* @param    none
* @return   argument of isConstant
*/
	
	public boolean isConstant() {
		return Argument.isConstant();
	}
	
/**
* toString describes the answer to the computations. 
* @param    none
* @return   cos argument
*/
	
	public java.lang.String toString() {
		return "cos( " + Argument.toString() + " )";
	}
}
