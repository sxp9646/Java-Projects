/*
 * Product.java
 *
 * Version:
 * $Id: Product.java,v 1.1 2014/10/08 03:05:12 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Product.java,v $
 * Revision 1.1  2014/10/08 03:05:12  sxp9646
 * *** empty log message ***
 *
 */

import java.util.ArrayList;

/**
 * Product serves as a class that contains various methods that 
 * use arraylists to organize data being gathered by the system.
 * Additionally, it is used to compute products. It has similar
 * functionality to Sum but works for products (*) rather than 
 * sums (+). 
 *
 * @author Suhail Prasathong sxp9646
 */


public class Product extends Function {
	private ArrayList<Function> istTerms = new ArrayList<Function>();
	public Product(Function... terms){
	    double var = 0.0;
	    for (Function f: terms){
	    	if (f instanceof Constant){
	    		if (var<= 0.0){
	    			var = f.evaluate(1.0);
	    		}
	    		else{
		    		var *= f.evaluate(1);
	    		}
	    	}
	    }
	    for (Function f: terms){
	    	if ((f instanceof Constant) == false){
	    		istTerms.add(f);
	    	}
	    }
	    if (var != 0.0){
	    	istTerms.add(new Constant(var));}
	}
	
/**
* Derivative illustrates the derivative of a constant. 
* @param    none
* @return   Constant also known as 0, new sum x. 
*/
	
	public Function derivative() {
		ArrayList<Function> lst5 = new ArrayList<Function>();
		int temp = 0;
		for (Function f: istTerms){
			if (f instanceof Variable){
				temp += 1;
			}
			lst5.add(f);
		}
		Function firstelement  = lst5.get(0);
		if (firstelement == null){
			return new Constant(0);
		}
		else if (lst5.size() == 1){
			return firstelement.derivative();
		}
		else{
			lst5.remove(0);
			Function[] n = new Function[lst5.size()];
			int i1 = 0;
			for (Function f: lst5){
				n[i1] = f;
				i1 += 1;
				}
			Function b = new Product(firstelement.derivative(), new Product(n));
			Function[] x = new Function[temp];
			while (temp != 0){
				x[temp-1] = b;
				temp -= 1;
			}
			return new Sum(x);	
		}
	}
	
/**
* Evaluate illustrates the integral of a double. 
* @param    none
* @return   f.
*/
	
	public double evaluate(double x) {
		double f = 0.0;
		for (Function f1: istTerms){
			if (f1.evaluate(x) == 0.0){
				return 0.0;
			}
			else{
				if (f == 0.0){
					f = f1.evaluate(x);
				}
				else{
					f *= f1.evaluate(x);}
			}
		}
		return f;
	}
	
	
/**
* Integral computes various functions in the sum format for
* further implementation. 
* @param    lower, upper, accuracy
* @return   tmp1
*/

	public double integral(double lower, double upper, double accuracy) {
		double deltax = upper - lower;
		deltax = deltax/accuracy;
		deltax = deltax/2;
		double temp = lower;
		double temp1 = 0;
		while (temp > upper == false){
			if (temp == lower || temp == upper){
				temp1 += this.evaluate(temp);
				temp += (upper-lower)/accuracy;
			}
			else{
				double temp3 = this.evaluate(temp);
				temp3 *= 2;
				temp1 += temp3;
				//temp += 1;
				temp += (upper-lower)/accuracy;
			}
		}
		temp1 = temp1 * deltax;
		return temp1;
	}
	
/**
* toString describes the answer to the computations. 
* @param    none
* @return   +proString+
*/

	
	public String toString() {
		String proString = istTerms.get(0).toString();
		for(int i = 1;i<istTerms.size();i++){
			proString+= " * "+ istTerms.get(i).toString();
		}
		return "("+proString+")";
	}

} //End Product Class
