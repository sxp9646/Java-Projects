/*
 * Sine.java
 *
 * Version:
 * $Id: Sine.java,v 1.1 2014/10/08 03:05:13 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Sine.java,v $
 * Revision 1.1  2014/10/08 03:05:13  sxp9646
 * *** empty log message ***
 *
 */

/**
 * Sine class serves to operate the derivative and
 * integral perspectives of the sine function in general
 * mathematics.
 * @author Suhail Prasathong sxp9646
*/

public class Sine extends Function{
	private Function SINE;
	
/**
* Sine describes the value of sine. 
* @param    none
* @return   none
*/
	
	public Sine(Function f){
		this.SINE = f;
	}
	
/**
* Derivative illustrates the derivative of a constant. 
* @param    none
* @return   Product(new Cosine(SINE). 
*/
	
	public Function derivative(){
		Function terms =SINE;
		return new Product(new Cosine(SINE), terms.derivative());
	}
	
/**
* Evaluate illustrates the integral of a double. 
* @param    none
* @return   Math.sin(Sine.evaluate(x));
*/
	
	public double evaluate(double x){
		return Math.sin(SINE.evaluate(x));
	}
	
/**
* isConstant illustrates a constant value. 
* @param    none
* @return   isconstant
*/
	
	public boolean isConstant(){
		boolean isconstant = true;
		if(SINE.isConstant()==false){
			isconstant = false;
		}
		return isconstant;
	}
	
	/**
	* toString describes the answer to the computations. 
	* @param    none
	* @return   sine( "+sinString+")
	*/
		
	public String toString(){
		String sinString = SINE.toString();
		return "sine( "+sinString+" )";
	}

}