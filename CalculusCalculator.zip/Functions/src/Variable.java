/*
 * Variable.java
 *
 * Version:
 * $Id: Variable.java,v 1.1 2014/10/08 03:05:12 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Variable.java,v $
 * Revision 1.1  2014/10/08 03:05:12  sxp9646
 * *** empty log message ***
 *
 */

/**
 * Variable serves as a class that contains constants and 
 * methods that do basic evaluation and integration which can
 * then be called and used elsewhere for implementation.
 *
 * @author Suhail Prasathong sxp9646
 */


public class Variable extends Function{
	public static final Variable x = new Variable();
	private Variable(){
		
	}
	
/**
* Derivative illustrates the derivative of a constant. 
* @param    none
* @return   Constant value of 1. 
*/
	
	public Function derivative(){
		return new Constant(1);
	}
	
/**
* Evaluate illustrates the integral of a double. 
* @param    none
* @return   x.
*/
	
	public double evaluate(double x){
		return x;
	}
	
/**
* Integral illustrates the actual integral computation. 
* @param    lower, upper, accuracy
* @return   h*(upper+lower)/2 
*/
	
	public double integral(double lower, double upper, int accuracy){
		double h = (upper - lower);
		return h*(upper+lower)/2;
	}
	
	/**
	* toString describes the answer to the computations. 
	* @param    none
	* @return   x
	*/
	
	public String toString(){
		return "x";
	}

} //End Variable Class