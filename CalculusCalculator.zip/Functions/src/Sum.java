/*
 * Sum.java
 *
 * Version:
 * $Id: Sum.java,v 1.1 2014/10/08 03:05:12 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Sum.java,v $
 * Revision 1.1  2014/10/08 03:05:12  sxp9646
 * *** empty log message ***
 *
 */

import java.util.ArrayList;

/**
 * Sum serves as a class that contains various methods that 
 * use arraylists to organize data being gathered by the system.
 *
 * @author Suhail Prasathong sxp9646
 */

public class Sum extends Function {
	
	private ArrayList<Function> SumPlus;
	private int size;
	private ArrayList<Function> variables;
	private Function theConstant;
	
/**
* Sum computes various functions in the sum format for
* further implementation. 
* @param    Function terms
* @return   null
*/

	public Sum(Function ...terms) 
	{
		
		ArrayList<Function> sum = new ArrayList<Function>();
		ArrayList<Function> var = new ArrayList<Function>();
		ArrayList<Function> cnst = new ArrayList<Function>();
		
		if (terms.length == 0) {
			Function c = new Constant(0.0);
			cnst.add(c);
		}
		else {
			for (int i = 0; i < terms.length; i++ ) {
				Function term = terms[i];
				if (term.isConstant()) {
					cnst.add(term);
				}
				else {
					var.add(term);
					sum.add(term);
				}
			}
		}
		variables = var;
		double res = 0.0;
		for (Function g: cnst) {
			res += g.evaluate(0.0);
		}
		theConstant = new Constant(res);
		sum.add(theConstant);
		size = sum.size();
		SumPlus = sum;
	}
	
/**
* Derivative illustrates the derivative of a value. 
* @param    none
* @return   result. 
*/
	
	public Function derivative() {
		Function result;
		if (size == 0) {
			result = SumPlus.get(0).derivative();
		}
		else {
			Function[] args = new Function[size];
			for (int i = 0; i < size; i++) {
				args[i] = SumPlus.get(i).derivative();
			}
			result = new Sum(args);
		}
		return result;
	}
	
/**
* Evaluate illustrates the integral of a double. 
* @param    none
* @return   result.
*/
	
	public double evaluate(double x) {
		double res = 0.0;
		for (Function s: SumPlus) {
			res += s.evaluate(x);
		}
		return res;
	}
	
/**
* isConstant illustrates a constant value. 
* @param    none
* @return   comparison of length of variable
*/
	
	public boolean isConstant() {
		return variables.size() == 0;
	}
	
/**
* Integral illustrates the actual integral computation. 
* @param    lower, upper, accuracy
* @return   result of computation. 
*/
	
	public double integral(double lower, double upper, int accuracy) {
		double res = 0.0;
		for (Function s: SumPlus) {
			res += s.integral(lower,upper,accuracy);
		}
		return res;   
	}
	
/**
* toString describes the answer to the computations. 
* @param    none
* @return   string constant, result
*/
	
	public java.lang.String toString() {
		String result = "";
		double constant = theConstant.evaluate(0.0); 
		if (variables.size() == 0) {
			result += Double.toString(constant);
		}
		else {
			result += "( ";
			for (int i = 0; i < variables.size() - 1; i++) {
				result += variables.get(i).toString() + " + ";
			}
			result += variables.get(variables.size() - 1);
			if (constant != 0.0) {
				result += " + " + Double.toString(constant);
			}
			result += " )";
		}
		return result;
	}
} //End Sum Class
