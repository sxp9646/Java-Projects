/*
 * FnTest.java
 *
 * Version:
 * $Id: FnTest.java,v 1.1 2014/10/08 03:05:14 sxp9646 Exp $
 *
 * Revisions:
 * $Log: FnTest.java,v $
 * Revision 1.1  2014/10/08 03:05:14  sxp9646
 * *** empty log message ***
 *
 */


public class FnTest {

    /**
     * Create a sum of variables, and then apply
     * all the Function operations on them.
     * The integral will go from 0 to 10.
     * 
     * @param args not used
     */
    public static void main( String[] args ) {
        if ( args.length != 0 ) {
            System.err.println( "FnTest takes no command line arguments." );
            System.exit( 1 );
        }
        Variable var = Variable.x;
        Function f = new
            Sum( var, new Constant( 9 ), var, new Constant( 11 ) );
        System.out.println( "Function " + f );
        System.out.println( "Value at 0: " + f.evaluate( 0.0 ) );
        System.out.println( "Value at 10: " + f.evaluate( 10.0 ) );
        System.out.println( "Derivative: " + f.derivative() );
        double iResult = 0.0;
        iResult = f.integral( 0.0, 10.0, 1000000 );
        System.out.println( "Integral from 0 to 10: " + iResult );
    }

} //End FnTest Class