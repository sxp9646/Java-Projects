/*
 * Function.java
 *
 * Version:
 * $Id: Function.java,v 1.1 2014/10/08 03:05:13 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Function.java,v $
 * Revision 1.1  2014/10/08 03:05:13  sxp9646
 * *** empty log message ***
 *
 */

/**
 * The function class operates as a class with
 * methods such as isConstant and toString for
 * further outside implementation. 
 *
 * @author Suhail Prasathong sxp9646
 */


public abstract class Function 

{
	
/**
* Function is simply a constructor in this case. 
* @param    none
* @return   none
*/

	public Function()
	{
	}
	
/**
* Derivative illustrates the derivative of a constant. 
* @param    none
* @return   Constant also known as 0. 
*/
	public abstract Function derivative();
	
/**
* Evaluate illustrates the integral of a constant. 
* @param    none
* @return   value of the integral over a constant.
*/
	
	public abstract double evaluate(double x);
	
/**
* Integral illustrates the actual integral computation. 
* @param    lower, upper, accuracy
* @return   (upper-lower)*(value) upper limit subtracted by lower limit
* multiplied by the inner. 
*/
	
	public double integral(double lower, double upper, int accuracy){return 0;

	}
	
/**
* isConstant illustrates a constant value. 
* @param    none
* @return   false
*/
	
	public boolean isConstant()

	{
		return false;
	}
	
/**
* toString describes the answer to the computations. 
* @param    none
* @return   none
*/
	
	public abstract String toString();
	
} //End Class Function
