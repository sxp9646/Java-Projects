/*
 * Constant.java
 *
 * Version:
 * $Id: Constant.java,v 1.1 2014/10/08 03:05:14 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Constant.java,v $
 * Revision 1.1  2014/10/08 03:05:14  sxp9646
 * *** empty log message ***
 *
 */

/**
 * Constant serves as a class that contains methods 
 * such as the evaluate, integral and so on that allow
 * other classes or the test class to call for further
 * implementation.
 *
 * @author Suhail Prasathong sxp9646
 */


public class Constant extends Function{
	private double value;
	
/**
* Constant defines a constant value. 
* @param    value
* @return   None
*/
	
	public Constant(double value){
		this.value = value;
	}
	
/**
* Derivative illustrates the derivative of a constant. 
* @param    none
* @return   Constant also known as 0. 
*/
	
	public Function derivative(){
		return new Constant(0);
	}
	
/**
* Evaluate illustrates the integral of a constant. 
* @param    none
* @return   value of the integral over a constant.
*/
	
	public double evaluate(double x){
		return this.value;
	}
	
/**
* Integral illustrates the actual integral computation. 
* @param    lower, upper, accuracy
* @return   (upper-lower)*(value) upper limit subtracted by lower limit
* multiplied by the inner. 
*/
	
	public double integral(double lower, double upper, int accuracy){
		return (upper-lower)*(value);
	}
	
/**
* isConstant illustrates a constant value. 
* @param    none
* @return   true
*/
	
	public boolean isConstant(){
		return true;
	}
	
/**
* toString describes the answer to the computations. 
* @param    none
* @return   the final value
*/
	
	public String toString(){
		return String.valueOf(value);
	}

} //End Class Constant
