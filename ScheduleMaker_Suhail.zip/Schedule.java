/**
 * 
 */

/**
 * 
 * Schedule.java
 *
 * Version:
 * $Id: Schedule.java,v 1.1 2014/09/10 02:12:24 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Schedule.java,v $
 * Revision 1.1  2014/09/10 02:12:24  sxp9646
 * Initial Revision
 *
 */

import java.util.ArrayList;

/**
 * Derives information that then prints out the schedule 
 * as required by the javadocs.
 *
 * @author Suhail Prasathong
 *
 *
 */


public class Schedule {

	private ArrayList<Course> crse;
	public Schedule () 

	{
		this.crse = new ArrayList<Course>();
	}
	
/**
* contains: essentially gathers course information then checks for
* conflicts and returns respectively. 
* @param    Course c      identifier of course
* @return   acknowledgement whether conflict exists or not.
*/
	
	public boolean contains (Course c) 

	{
		for(int i=0; i < this.crse.size(); i++) 
		{
			if(this.crse.get(i).equals(c)) 
			{
				return true;
			}

			else if(this.crse.get(i).inConflict(c))
			{
				return true;
			}

			else 
			{
				return false;
			}
		}
		return false;

	}

/**
* add: method simply adds the course then returns
* respectively. 
* @param    Course c      identifier of course
* @return   acknowledgement whether when to add course or not.
*/

	
	public boolean add (Course c)

	{
		if(contains(c))
		{
			return false;
		}
		else
		{
			this.crse.add(c);
			return true;
		}

	}

/**
* toString method simply returns string as described in
* in javadocs. 
* @param    none
* @return   statements describing specific schedule/course entry.
*/
	
	public String toString() 
	
	{
		return "Schedule with " + this.crse.size() + "courses";
	}

/**
* prettyPrint consists various cases that assist in printing
* the day along with other course information.
* @param    none for method
* @return   uses while loop with switch statement in it.
*/
	
	public void prettyPrint() 
	
	{
		int b = 0;
		while(b<=4) 
		{
			switch(b)
			{
			
			case 0: System.out.println("----Monday----");

			for(int i = 0; i < crse.size(); i++)
			{
				if(this.crse.get(i).getDays().get(0) == true)
				{
					System.out.println(this.crse.get(i).getStart() 
					+ "-" + this.crse.get(i).getEnd() + ": " + this.crse.get(i).getName());
				}
			}
			b++;
			break;


			case 1: System.out.println("----Tuesday----");

			for(int i = 0; i < crse.size(); i++)
			{
				if(this.crse.get(i).getDays().get(1) == true)
				{
					System.out.println(this.crse.get(i).getStart() 
					+ "-" + this.crse.get(i).getEnd() + ": " + this.crse.get(i).getName());
				}
			}
			b++;
			break;
					
			case 2: System.out.println("----Wednesday----");

			for(int i = 0; i < crse.size(); i++)
			{
				if(this.crse.get(i).getDays().get(2) == true)
				{
					System.out.println(this.crse.get(i).getStart() 
					+ "-" + this.crse.get(i).getEnd() + ": " + this.crse.get(i).getName());
				}
			}
			b++;
			break;
			
					
			case 3: System.out.println("----Thursday----");

			for(int i = 0; i < crse.size(); i++)
			{
				if(this.crse.get(i).getDays().get(3) == true)
				{
					System.out.println(this.crse.get(i).getStart() 
					+ "-" + this.crse.get(i).getEnd() + ": " + this.crse.get(i).getName());
				}
			}
			b++;
			break;
					
			case 4: System.out.println("----Friday----");

			for(int i = 0; i < crse.size(); i++)
			{
				if(this.crse.get(i).getDays().get(4) == true)
				{
					System.out.println(this.crse.get(i).getStart() 
					+ "-" + this.crse.get(i).getEnd() + ": " + this.crse.get(i).getName());
				}
			}
			b++;
			break;
			
			}
		}
	} 
		
	
} //Class Schedule end


