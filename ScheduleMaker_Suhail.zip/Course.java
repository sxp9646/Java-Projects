/**
 * 
 */

/**
 * 
 * Course.java
 *
 * Version:
 * $Id: Course.java,v 1.1 2014/09/10 02:12:25 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Course.java,v $
 * Revision 1.1  2014/09/10 02:12:25  sxp9646
 * Initial Revision
 *
 */

import java.util.*;

/**
 * This class contains methods that show courses with 
 * the appropriate days and schedule. It also notices conflicts,
 * defines strings and so on. 
 *
 * @author Suhail Prasathong
 *
 *
 */

public class Course extends Object {
	
	private String Name;
	private ArrayList<Boolean> days;
	private int start;
	private int end;
	
/**
* The static string dayString is a field that contains 
* all possible days in order ex. MTWRF. 
*/ 
	public static final String dayString = "MTWRF";
	
	public  Course(String Name, ArrayList<Boolean> days, int start, int end){
		
		this.Name = Name;
		this.days = days;
		this.start = start;
		this.end = end;
		
	}
	
	public String getName () {
		return this.Name;
	}
	
	public ArrayList<Boolean> getDays () {
		return this.days;
	}
	
	public int getStart () {
		return this.start;
	}
	
	public int getEnd () {
		return this.end;
	}

/**
* The equals method is used to compare strings and 
* other attributes as required. 
* @param    Object obj      identifier of obj
* @return   returns boolean values based on conclusions of 
* the if statement.
*/	
	
	public boolean equals (Object obj){
		
		if(obj instanceof Course){
			Course crs = (Course) obj;
			if(this.Name .equals(crs.getName()) && this.days == crs.getDays() 
					&& this.start == crs.getStart() && this.end == crs.getEnd()){
				return true;
			}

			else {
				return false;
			}

		}
		else{
			return false;
		}

	}

/**
* The inConflict method is used to search for conflicts 
* with days, time etc. within the course. 
* @param    Course crs      identifier of crs
* @return   acknowledges return values that clarify conflicts.
*/	
	
	public boolean inConflict (Course crs) {
		for(int i = 0; i < crs.getDays().size(); i++) {
			if(crs.getDays().get(i) == this.days.get(i)) {
				if(this.start < crs.getStart() || this.end > crs.getStart()) {
					return true;	
				}

				else {
					if(this.start > crs.getEnd() || this.end > crs.getEnd()) {
						return true;
					}
					else {
						return false;
					}
				}
			}
			else { 
				return false;
			}

		}
		return false;

	}
	
/**
* The toString method is used to check for when to print
* the right days for when the course is being held. 
* @param    None
* @return   returns statement of attributes of 
* 			the course respectively.
*/	

	public String toString () 
	{
		String tmp="";
		for(int i=0; i < this.days.size(); i++) 
		{
			if(this.days.get(i) == true) 
			{
				tmp += dayString.charAt(i);
			}

		}
		return this.Name + ": " + tmp + " at " + this .start + "-" + this.end;

	}
	
/**
* The inDay method checks for the course that is being
* run during the day and its other attributes such as 
* start time, end time etc. 
* @param    int day    identifies day integer
* @return   returns start and end times with the name of the
* course that is being held. In the case that the if statement
* does not hold true, method returns blank (""). 
*/	
	
	
	public String inDay (int day)
	{
		if(this.days.get(day) == true)
		{
			return this.start + "-" + this.end + ": " + this.Name;
		}
		else

		{
			return "";
		}
	}


} //Class Course end
	

	



