/*
 * TrollsBridge.java
 *
 * Version:
 * $Id: TrollsBridge.java,v 1.2 2014/12/03 03:43:49 sxp9646 Exp $
 *
 * Revisions:
 * $Log: TrollsBridge.java,v $
 * Revision 1.2  2014/12/03 03:43:49  sxp9646
 * *** empty log message ***
 *
 */


import java.util.LinkedList;
import java.util.Queue;
// imports go here, if any.

/**
 * TrollsBridge serves as the basis for the bridge to be created 
 * and for woolies to be sorted on them.
 *
 * @author Suhail Prasathong, SXP9646
 */


public class TrollsBridge {

	private int max; 
	private int woolieOnBrge;
	private Queue<Woolie> waitlist; 

	public TrollsBridge() {
		// TODO Auto-generated constructor stub

		
	}
	public TrollsBridge(int max) {
		this.max = max;
		this.woolieOnBrge = 0;
		this.waitlist = new LinkedList<Woolie>();
	}

 /**
* enterBridge takes into account when woolies enter the bridge. 
* @param    Woolie
* @return   
*/
	
	public synchronized void enterBridge(Woolie thisWoolie) {
		waitlist.add(thisWoolie);
		System.out.println("The troll scowls \"Get in line!\" when " + 
						thisWoolie.getWoolieName() + " shows up at the bridge.");
		
		while(woolieOnBrge == max || waitlist.peek() != thisWoolie) {
			try {
				wait();
			} catch (InterruptedException e) {
				System.err.println(
					"InterruptedException: Could not place thread on wait().");
			}
		}
		woolieOnBrge += 1;
		waitlist.remove(thisWoolie);
	}
	
 /**
* leave takes into account when woolies leave the bridge. 
* @param    
* @return   
*/
	
	public synchronized void leave() {
		// TODO Auto-generated method stub
		this.woolieOnBrge -= 1;
		notifyAll();
	}
	
/**
* isFull takes into account when bridge is full of woolies. 
* @param    
* @return   
*/
	public boolean isFull() {
		return this.max == woolieOnBrge;
	}

}
