/*
 * Woolie.java
 *
 * Version:
 * $Id: Woolie.java,v 1.2 2014/12/03 03:43:49 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Woolie.java,v $
 * Revision 1.2  2014/12/03 03:43:49  sxp9646
 * *** empty log message ***
 *
 */

// imports go here, if any.

/**
 * Woolie serves as the creator for all woolies and sets its parameters.
 *
 * @author Suhail Prasathong SXP9646.
 */

public class Woolie extends Thread {

	String name;
	int crossTime;
	String destination;
	TrollsBridge bridgeGuard;
	
	
	/**
     * Woolie generates names and placeholders. 
     * @param    name, crossTime, destination and bridgeGuard
     * @return   
     */
	public Woolie(String name,
            int crossTime,
            String destination,
            TrollsBridge bridgeGuard){
		
		this.name = name;
		this.crossTime = crossTime;
		this.destination = destination;
		this.bridgeGuard = bridgeGuard;
	}
	
	/**
     * run interfaces the moving and interfacing of the woolies. 
     * @param    elapsedTime
     * @return   name
     */
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		int elapsedTime = 0;
		
		bridgeGuard.enterBridge(this);
		System.out.println(this.name + " is starting to cross.");
		
		while(elapsedTime < this.crossTime - 1) {
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.err.println(
					"InterruptedException: Could not place thread on sleep().");
			}
			System.out.println("\t" + this.name + " " + (elapsedTime + 1) + " seconds.");
			elapsedTime += 1;
		}
		System.out.println(this.name + " leaves at " + this.destination + ".");
		
		bridgeGuard.leave();
	}
	
	/**
     * getWoolieName accesses the name of the woolie then places it in the right location. 
     * @param    
     * @return   name
     */
	
	public String getWoolieName() {
		return this.name;
	}


}
