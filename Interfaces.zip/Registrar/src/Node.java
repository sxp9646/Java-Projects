/*
 * Node.java
 *
 * Version:
 * $Id: Node.java,v 1.1 2014/09/17 03:34:03 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Node.java,v $
 * Revision 1.1  2014/09/17 03:34:03  sxp9646
 * *** empty log message ***
 *
 */

// imports go here, if any.

/**
 * Node exists so it can easily be called in LinkedQueue class.
 *
 * @author Suhail Prasathong sxp9646 
 * 		   (Code provided by the instructor).
 */




public class Node<E> {
    public E data;
    public Node<E> next;
    
    public Node(E data, Node<E> next) {
        this.data = data;
        this.next = next;
    }

    public E getData() { return this.data; }
    public void setData(E data) { this.data = data; }
    public Node<E> getNext() { return next; }
    public void setNext(Node<E> next) { this.next = next; }

}
