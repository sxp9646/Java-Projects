/*
 * Registrar.java
 *
 * Version:
 * $Id: Registrar.java,v 1.1 2014/09/17 03:34:03 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Registrar.java,v $
 * Revision 1.1  2014/09/17 03:34:03  sxp9646
 * *** empty log message ***
 *
 */

import java.util.*;

/**
 * Registrar serves as the class that handles all the input/output
 * aspects of the project.
 *
 * @author Suhail Prasathong sxp9646
 */
public class Registrar 

{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	
	{
		Scanner in = new Scanner (System.in);	
		Boolean done = false;
		HeapQueue <Student> hq = new HeapQueue ();
		
		
		while(done != true) 
		{
			System.out.println("1: Add student ");
			System.out.println("2: Take highest-priority student ");
			System.out.println("3: Quit ");
						
			
			int input = in.nextInt();
			if(input == 1)
			{
				System.out.println("Name: ");
				String name = in.next();
				System.out.println("Year: ");
				int year = in.nextInt();
				System.out.println("GPA: ");
				double gpa = in.nextDouble();	
				
				Student newStudent = new Student (name, year, gpa);
				hq.insert(newStudent);
			}
			
			else if(input == 2)
			{
				Student oldStudent = hq.dequeue();
				System.out.println(oldStudent.getName() + " has greatest priority. \n");
			}
			
			else if (input == 3)
			{
				System.out.println("Exit. ");
				done = true; 
			}
			
		}
	
	}

} //end Class Registrar
