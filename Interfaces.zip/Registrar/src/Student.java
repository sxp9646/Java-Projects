/*
 * Student.java
 *
 * Version:
 * $Id: Student.java,v 1.1 2014/09/17 03:34:02 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Student.java,v $
 * Revision 1.1  2014/09/17 03:34:02  sxp9646
 * *** empty log message ***
 *
 */

import java.util.*;
import java.util.PriorityQueue;

/**
 * Student serves as a class that initializes the major
 * components required to compute a value by which the priority
 * is ranked. The class also computes a score which is then used to 
 * base priority respectively. 
 *
 * @author Suhail Prasathong sxp9646
 */


public class Student implements Prioritizable 

{	
	private String Name;
	private int Year;
	private double GPA;
	
	
	PriorityQueue data = new PriorityQueue();
	
	public void addStudent(String studentData) 
		
		{
			data.add(studentData);
		}
	
	/**
     * Student simply describes the attributes of the student.
     * These would then be used to weigh out the priority. 
     * @param    Name, Year, GPA      attributes of a student
     */
	
	public Student (String Name, int Year, double GPA)
		
		{
			this.Name = Name;
			this.Year = Year;
			this.GPA = GPA;
		}
	
	/**
     * getPriority contains a very basic formula that allows for
     * the calculation for the priority of a student. 
     * @return a "score" that distinguishes between students.
     */
	
	public double getPriority() 

		{
			return (Year * 10) + GPA ;
		} 
	
	/**
     * getName simply returns the name of the student. 
     * @return It returns the student's name.
     */
	
	public String getName()
		
		{
			return Name;
		}
	
} //end Class Student

