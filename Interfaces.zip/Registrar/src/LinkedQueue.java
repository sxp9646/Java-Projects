/*
 * LinkedQueue.java
 *
 * Version:
 * $Id: LinkedQueue.java,v 1.1 2014/09/17 03:34:03 sxp9646 Exp $
 *
 * Revisions:
 * $Log: LinkedQueue.java,v $
 * Revision 1.1  2014/09/17 03:34:03  sxp9646
 * *** empty log message ***
 *
 */

import java.util.*;

/**
 * LinkedQueue serves as an example of recommended Java coding style.
 *
 * @author Suhail Prasathong sxp9646
 */


public class LinkedQueue<E extends Prioritizable> implements PriorityQueue<E>{
	
	public Node<E> head;
	public Node<E> tail;
	public int size;
	LinkedList list = new LinkedList();

	public LinkedQueue() {
		size = 0;
		head = new Node<E>(null,head);
		tail = new Node<E>(null,tail);
	}
	
	/**
     * size simply accesses the size. 
     * @return returns size of the list.
     */

	public int size()

	{
		return size;
	}
	
	/**
     * isEmpty function checks to see if the list is empty. 
     * @return returns list which is checked to see whether it's
     * empty or not.
     */
	
	public boolean isEmpty() 
		
	{
		boolean resultValue = true;
		
		if(head.next == null)
		{
			resultValue = true;
		}
		
		else
		{
			resultValue = false;
		}
		
		return resultValue;
	}
	
	
	/**
     * isEmpty function checks to see if the list is empty. 
     * @return returns list which is checked to see whether it's
     * empty or not.
     */

	@Override
	public void insert(E toInsert) 
	
	{
		if (isEmpty() == true)
		{
			head.next = new Node<E>(toInsert, null);
			System.out.println(head.data.toString());
		}
		else 
		{
			Node<E> pointer = this.head;
			boolean finish = false;
			while (pointer.next != null & !finish)
			{
				if(pointer.next.data.getPriority() <toInsert.getPriority())
				{
					Node<E> temp = pointer.next;
					pointer.next = new Node<E> (toInsert, null);
					pointer.next.next = temp;
					finish = true;
				}
				
				pointer = pointer.next;
			}
			if(finish = false) {
				pointer.next = new Node<E> (toInsert, null);
			}
			Node<E> position = this.head;
		}
	}
	
	/**
     * isEmpty function checks to see if the list is empty. 
     * @return returns list which is checked to see whether it's
     * empty or not.
     */

	@Override
	public E dequeue() 

	{

		if(this.head.next == null) 

		{
			return null;
		}

		else
		{
			Node<E> pointer = this.head;
			if (pointer.next == null)
			{
				Node<E> temp = pointer;
				pointer = new Node<E>(null, temp.next);
				this.head = pointer;
				return temp.data;
			}
			else
			{
				return null;
			}

		}
	}
	
}



