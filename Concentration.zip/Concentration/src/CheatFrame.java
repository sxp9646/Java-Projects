/*
 * CheatFrame.java
 *
 * Version:
 * $Id: CheatFrame.java,v 1.1 2014/11/12 05:00:33 sxp9646 Exp $
 *
 * Revisions:
 * $Log: CheatFrame.java,v $
 * Revision 1.1  2014/11/12 05:00:33  sxp9646
 * *** empty log message ***
 *
 */


import java.awt.*;
import java.util.*;

import javax.swing.*;


/**
 * CheatFrame operates on behalf of the main gui for the cheat button.
 *
 * @author sxp9646
 */

public class CheatFrame extends JFrame {

	Color[] colors = {
			Color.RED,	Color.GREEN, Color.BLACK, Color.YELLOW, Color.BLUE, Color.DARK_GRAY,
			Color.CYAN, Color.MAGENTA
		};
	
	/**
     * CheatFrame serves as the constructor for layout and other operations in the cheat button on the main gui. 
     * @param    jobNum      identifier of the job to do
     * @return   
     */
	
	public CheatFrame(ArrayList<CardButton> buttons, int size,
			ConcentrationModel model) {
		
		
		ArrayList<CardFace> cardFaces = model.cheat();
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(4,4));
		for(int i =0; i<buttons.size();i++){
			JButton button = new JButton("" + CardButton.getNumber());
			buttons.get(i);
			button.setText(""+cardFaces.get(i));
		 	button.setBackground(colors[cardFaces.get(i).getNumber()]);
			button.setForeground(Color.WHITE);
			panel.add(button);
			
			
		}
		add(panel, BorderLayout.CENTER);
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	
		
		
	}



	//create grid objects
	//display grid objects
}
