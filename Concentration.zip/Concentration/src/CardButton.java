/*
 * CardButton.java
 *
 * Version:
 * $Id: CardButton.java,v 1.1 2014/11/12 05:00:32 sxp9646 Exp $
 *
 * Revisions:
 * $Log: CardButton.java,v $
 * Revision 1.1  2014/11/12 05:00:32  sxp9646
 * *** empty log message ***
 *
 */

import javax.swing.JButton;

/**
 * CardButton represents the button for which it stands for a card.
 *
 * @author sxp9646
 */

public class CardButton extends JButton {
	private static final long serialVersionUID = 1L;
	int position;
	

	public CardButton(int i){
		this.position = i;
	}
	
	/**
     * getPosition accesses position. 
     * @param    jobNum      identifier of the job to do
     * @return   position
     */
	public int getPosition(){
		return position;
	}
	
	/**
     * getNumber accesses number. 
     * @param    jobNum      identifier of the job to do
     * @return   null
     */

	public static String getNumber() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
