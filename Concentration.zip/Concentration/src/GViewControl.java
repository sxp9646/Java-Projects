/*
 * CardButton.java
 *
 * Version:
 * $Id: GViewControl.java,v 1.1 2014/11/12 05:00:33 sxp9646 Exp $
 *
 * Revisions:
 * $Log: GViewControl.java,v $
 * Revision 1.1  2014/11/12 05:00:33  sxp9646
 * *** empty log message ***
 *
 */


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;


/**
 * GViewControl serves as the heart and soul of the program where all the accessing of cards, flipping etc is done.
 *
 * @author sxp9646
 */

public class GViewControl extends JFrame implements Observer {

	private static final long serialVersionUID = 1L;
	private ConcentrationModel model;
	private ArrayList<CardButton> buttons;
	private JLabel label;

	Color[] colors = {
		Color.RED,	Color.GREEN, Color.BLACK, Color.YELLOW, Color.BLUE, Color.DARK_GRAY,
		Color.CYAN, Color.MAGENTA
	};

	/**
     * GViewControl serves as the layout manager. 
     * @param    jobNum      identifier of the job to do
     * @return   
     */
	
	public GViewControl(ConcentrationModel model)
	{

		this.model = model;
		buttons = new ArrayList<CardButton>();
		model.addObserver(this);
		JPanel top = new JPanel();
		top.setLayout(new GridLayout(4, 4));
		JPanel north = new JPanel();
		JPanel south = new JPanel();
		north.setLayout(new FlowLayout(FlowLayout.LEFT));
		south.setLayout(new FlowLayout(FlowLayout.RIGHT));
		this.label = new JLabel("Moves: 0 Select the first card.");
		north.add(this.label);
		JButton reset = new JButton("Reset");
		JButton cheat = new JButton("Cheat");
		JButton undo = new JButton("Undo");
		south.add(reset);
		south.add(cheat);
		south.add(undo);
		reset.addActionListener(new ActionListener()
								{
									@Override
									public void actionPerformed(ActionEvent e)
									{
										model.reset();
									}
								});
		cheat.addActionListener(new ActionListener()
								{
									@Override
									public void actionPerformed(ActionEvent e)
									{
										model.cheat();
										new CheatFrame(buttons, buttons.size(), model);
									}
								});

		undo.addActionListener(new ActionListener()
							   {
								   @Override
								   public void actionPerformed(ActionEvent e)
								   {
									   model.undo();
								   }
							   });

		for (int cardNumber = 0; cardNumber < 16; cardNumber++)
		{
			CardButton cardButton = new CardButton(cardNumber);
			cardButton.setForeground(Color.WHITE);
			cardButton.setBackground(Color.BLACK);
			buttons.add(cardButton);
			top.add(cardButton);
			cardButton.setBorderPainted(true);
			cardButton.setContentAreaFilled(false);
			cardButton.setOpaque(true);
			cardButton.addActionListener(new ActionListener()
										 {
											 @Override
											 public void actionPerformed(ActionEvent e)
											 {
												 model.selectCard((((CardButton)e.getSource()).position));
											 }
										 });
		}

		this.add(top, BorderLayout.CENTER);
		this.add(north, BorderLayout.NORTH);
		this.add(south, BorderLayout.SOUTH);
		setTitle("Concentration Game");
		setSize(500, 500);
		this.setLocation(100, 100);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	/**
     * update keeps track of the update counter of moves. 
     * @param    jobNum      identifier of the job to do
     * @return   moves
     */

	@Override
	public void update(Observable arg0, Object arg1)
	{
		String numMoves = "" + model.getMoveCount();
		int numCardsup = model.howManyCardsUp();

		if (numCardsup == 0)
		{
			label.setText("Moves: " + numMoves + " Select first card");
		}
		else if (numCardsup == 1)
		{
			label.setText("Moves: " + numMoves + "Select second card");
		}
		else
		{
			label.setText("Moves: " + numMoves + "Select first card");
		}
		{

			ArrayList<CardFace> cardFaces = model.getCards();
			for (int index = 0; index < 16; index++)
			{
				CardButton currentCard = buttons.get(index);
				CardFace cardFace = cardFaces.get(index);
				if (cardFace.isFaceUp())
				{
					currentCard.setText("" + cardFace.getNumber());
					currentCard.setBackground(colors[cardFace.getNumber()]);
				}
				else
				{
					currentCard.setText("");
					currentCard.setBackground(null);
				}
			}
		}
	}
	
	/**
     * the main class handles observer views. 
     * @param    jobNum      identifier of the job to do
     * @return   
     */

	public static void main(String[] args)
	{
		ConcentrationModel model = new ConcentrationModel();
		Observer view = new GViewControl(model);
		model.addObserver(view);
	}
}