/*
 * PaperbackBook.java
 *
 * Version:
 * $Id: PaperbackBook.java,v 1.1 2014/09/23 23:28:05 sxp9646 Exp $
 *
 * Revisions:
 * $Log: PaperbackBook.java,v $
 * Revision 1.1  2014/09/23 23:28:05  sxp9646
 * *** empty log message ***
 *
 */


/**
 * PaperbackBook is a class that is called to represent paperback books in the bookstore.
 *
 * @author Suhail Prasathong sxp9646
 */
public class PaperbackBook extends Book {
	
	private static Media p;
	private int theURL;
	
	public PaperbackBook (String title, String author, int cost)
	{
		super(title,author,cost,p.Paperback);
		
	}
	
/**
* isForSale is an abstract method. 
* @param    No parameters.
* @return   Does not return anything. 
*/
	
	public boolean isForSale()
	{
		return true;
	}
	
/**
* toString prints the string based on requirements. 
* @param    No parameters.
* @return   string.
*/
	
	public String toString()
	{
		return super.getTitle() + "." + "\n\t" + super.getAuthor() +"." + "\n\t" + "Paperback." ;
	}
}
