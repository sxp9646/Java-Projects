/*
 * Book.java
 *
 * Version:
 * $Id: Book.java,v 1.1 2014/09/23 23:28:05 sxp9646 Exp $
 *
 * Revisions:
 * $Log: Book.java,v $
 * Revision 1.1  2014/09/23 23:28:05  sxp9646
 * *** empty log message ***
 *
 */

import java.util.ArrayList;
import java.util.Scanner;

/**
 * The book class contains all the vital
 * attributes of a traditional book which 
 * are then called into various other classes 
 * for multiple operational purposes.
 *
 * @author Suhail Prasathong sxp9646
 */

public abstract class Book 

{

	private String title;
	private String author;
	private int cost;
	private Media media;

/**
* doSomeJob illustrates a verb phrase method name. 
* @param    jobNum      identifier of the job to do
* @return   acknowledgement whether or not request was accepted
*/	

	public Book(String title, String author, int cost, Media media)
	{
		this.title = title;
		this.author = author;
		this.cost = cost;
		this.media = media;
	}

/**
* isForSale is an abstract method. 
* @param    No parameters.
* @return   Does not return anything. 
*/

	public abstract boolean isForSale ();
	
/**
* getTitle accesses the title of a book. 
* @param    No parameters.
* @return   title of the book. 
*/
	
	public String getTitle () 
	{
		return  '"' + this.title + '"';
	}
	
/**
* getAuthor accesses the author of a book. 
* @param    No parameters.
* @return   author of the book. 
*/

	public String getAuthor () 
	{
		return this.author;
	}

/**
* getCost contains the cost with its mathematical
* computation allowing it to show in dollars and cents. 
* @param    No parameters.
* @return   cost of the book in dollars. 
*/

	public double getCost () 
	{
		return this.cost / 100.0;
	}
	
/**
* getMedia contains media that has various media types. 
* @param    No parameters.
* @return   media as string.
*/	

	public String getMedia () 
	{
		return this.media.toString();
	}
	
/**
* toString prints the string based on requirements. 
* @param    No parameters.
* @return   string.
*/

	public String toString () 

	{
		return "	" + this.title + "." + " \n " + "	" + this.author + "." + " \n " + "	" 
				+ getMedia() + ".";
	}



}

