/*
 * HardcoverBook.java
 *
 * Version:
 * $Id: HardcoverBook.java,v 1.1 2014/09/23 23:28:05 sxp9646 Exp $
 *
 * Revisions:
 * $Log: HardcoverBook.java,v $
 * Revision 1.1  2014/09/23 23:28:05  sxp9646
 * *** empty log message ***
 *
 */


/**
 * HardcoverBook is a class that is called to represent hardcover books in the bookstore.
 *
 * @author Suhail Prasathong sxp9646
 */
public class HardcoverBook extends Book {
	
	private static Media h;
	private String coverMaterial;
	
	public HardcoverBook (String title, String author, int cost, String coverMaterial)
	{
		super(title,author,cost,h.Hardcover);
		this.coverMaterial = coverMaterial;
	}
	
/**
* getCoverMaterial prints the material type for hard
* -cover books. 
* @param    No parameters.
* @return   cover material. 
*/

	public String getCoverMaterial()
	{
		return "Hardcover " + coverMaterial;
	}
	
/**
* isForSale is an abstract method. 
* @param    No parameters.
* @return   Does not return anything. 
*/
	
	public boolean isForSale()
	{
		return true;
	}
	
/**
* toString prints the string based on requirements. 
* @param    No parameters.
* @return   string.
*/
	
	public String toString()
	{
		return super.getTitle() +"." + "\n\t" + super.getAuthor() +"." + "\n\t"  + getCoverMaterial() + ".";
	}
	

}
