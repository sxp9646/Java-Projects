/*
 * AudioBook.java
 *
 * Version:
 * $Id: AudioBook.java,v 1.1 2014/09/23 23:28:05 sxp9646 Exp $
 *
 * Revisions:
 * $Log: AudioBook.java,v $
 * Revision 1.1  2014/09/23 23:28:05  sxp9646
 * *** empty log message ***
 *
 */


/**
 * AudioBook is a class that is called to represent audiobooks in the bookstore.
 *
 * @author Suhail Prasathong sxp9646
 */


public class AudioBook extends Book {
	
	private static Media m;
	private int numDisks;
	
	public AudioBook (String title, String author, int cost, int numDisks)
	{
		super(title,author,cost,m.Audio);
		this.numDisks = numDisks;
	}
	
	/**
	* getMedia contains media that has various media types. 
	* @param    No parameters.
	* @return   media as string.
	*/
	
	@Override
	public String getMedia()
	{
		return "Audio";
	}
	
	/**
	* isForSale is an abstract method. 
	* @param    No parameters.
	* @return   Does not return anything. 
	*/
	
	public boolean isForSale()
	{
		return false;
	}
	
	/**
	* toString prints the string based on requirements. 
	* @param    No parameters.
	* @return   string.
	*/
	
	public String toString()
	{
		return super.getTitle() + "." +"\n\t" + super.getAuthor() + "." +"\n\t" + "Audio:" + this.numDisks + ".";
	}
}
