/*
 * ElectronicBook.java
 *
 * Version:
 * $Id: ElectronicBook.java,v 1.1 2014/09/23 23:28:05 sxp9646 Exp $
 *
 * Revisions:
 * $Log: ElectronicBook.java,v $
 * Revision 1.1  2014/09/23 23:28:05  sxp9646
 * *** empty log message ***
 *
 */


/**
 * ElectronicBook is a class that is called to represent electronic books in the bookstore.
 *
 * @author Suhail Prasathong sxp9646
 */
public class ElectronicBook extends Book {
	
	private static Media e;
	private String theURL;
	
	public ElectronicBook (String title, String author, int cost, String theURL)
	{
		super(title,author,cost,e.Electronic);
		this.theURL = theURL;
	}
	
	
/**
* getMedia contains media that has various media types. 
* @param    No parameters.
* @return   media as string.
*/
	
	public String getMedia()
	{
		return " Electronic " + " : {URL}";
	}
	
/**
* isForSale is an abstract method. 
* @param    No parameters.
* @return   Does not return anything. 
*/
	
	public boolean isForSale()
	{
		return false;
	}
	
/**
* toString prints the string based on requirements. 
* @param    No parameters.
* @return   string.
*/
	
	public String toString()
	{
		return super.getTitle() +"." + "\n\t" + super.getAuthor() 
				+ "." + "\n\t" + this.theURL;
	}
	

}
