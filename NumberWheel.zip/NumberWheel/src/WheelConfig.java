/*
 * WheelConfig.java
 *
 * Version:
 * $Id: WheelConfig.java,v 1.2 2014/10/29 06:05:57 sxp9646 Exp $
 *
 * Revisions:
 * $Log: WheelConfig.java,v $
 * Revision 1.2  2014/10/29 06:05:57  sxp9646
 * *** empty log message ***
 *
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Scanner;


/**
 * WheelConfig serves as a class that contains all operations.
 * @author Suhail Prasathong sxp9646
 */

public class WheelConfig implements Configuration {
	
	int numberTriads, count;
	File file;
	Integer[] Triad;
	private int totalVal;
	ArrayList<Integer> vals = new ArrayList<Integer>();
	ArrayList<Integer> nums = new ArrayList<Integer>();

	/**
	 * Constructs an initial number wheel puzzle from an input file whose format is: #_triads bridge1_value bridge2_value...A
	 * @param filename string containing file to run
	 * @throws FileNotFoundException if file not found this is thrown
	 */
	public WheelConfig(String filename) throws FileNotFoundException{
		file = new File(filename);
		Scanner in = new Scanner(file);
		this.numberTriads = in.nextInt();
		in.nextLine();
		String[] split = in.nextLine().split(" ");	
		for(int i=1; i<=numberTriads; i++){
			vals.add(Integer.parseInt(split[i-1]));
		}				
		for(int j=1; j<=(numberTriads*3); j++){
			nums.add(j);
		}
		this.Triad = new Integer[numberTriads*3];	
		for(int i=0; i< Triad.length; i++){
			if(Triad[i]==null){
				Triad[i]=0;
			}
		}

		for(int p:nums){
			totalVal+=p;
		}
		this.totalVal=this.totalVal/numberTriads;
		in.close();
	}

	/**
	 * Copy constructor. Takes incoming config and makes deep copy.
	 * @param config An instance of a wheelconfig to copy
	 */
	public WheelConfig(WheelConfig config){
		this.numberTriads = config.numberTriads;
		this.vals = new ArrayList<Integer>(config.vals);
		this.nums = new ArrayList<Integer>(config.nums);
		this.Triad = new Integer[numberTriads*3];
		this.totalVal=config.totalVal;
		System.arraycopy(config.Triad, 0, this.Triad, 0, (numberTriads*3));

	}


	/**
	 * Get successors from current one.
	 * 
	 */
	@Override
	public Collection<Configuration> getSuccessors() {
		ArrayList<Integer> tnums = new ArrayList<Integer>(nums);
		Collection<Configuration> successors = new LinkedList<Configuration>();
		boolean check = true;
		int flag = 0;
		while(check){
			if(flag >= numberTriads*3){
				check=false;
				return successors;
			}
			if(Triad[flag]==0){
				check = false;
				count = flag;
			}
			flag++;
		}

		for(int i : Triad){
			for(int j=0; j<tnums.size(); j++){
				if(i==tnums.get(j)){
					tnums.remove(j);
				}
			}
		}
		for(int y:tnums){
			WheelConfig c = new WheelConfig(this);
			c.Triad[count]=y;

			successors.add(c);

		}	

		return successors;
	}

	/**
	 * Check if current config is valid.
	 */
	@Override
	public boolean isValid() {
		ArrayList<Integer> bcopy = new ArrayList<Integer>(vals);
		int tempTotal;

		ArrayList<Integer> seen=new ArrayList<Integer>();

		
		for (int i = 1; i<numberTriads;i++){
			if(Triad[(3*i)-1]!=0 && (Triad[3*i]!=0)){
				if (bcopy.get(i-1)==Triad[(3*i)-1]+Triad[3*i]){
				}
				else {
					return false;
				}
			}
		}
		for(int i=1; i<= numberTriads; i++){
			if(Triad[(3*i)-3]!=0 &&
					Triad[(3*i)-2]!=0 &&
					Triad[(3*i)-1]!=0){
				tempTotal=Triad[(3*i)-3]+Triad[(3*i)-2]+Triad[(3*i)-1];
				if(tempTotal==totalVal){}
				else{
					return false;
				}	

			}
		}

		for(int i=0; i<numberTriads*3; i++){
			if(seen.contains(Triad[i])){
				return false;
			}
			else{
				if(Triad[i]!=0){
					seen.add(Triad[i]);	
				}

			}
		}
		

		return true;



	}
	/**
	 * Check if current config is goal.
	 */
	@Override
	public boolean isGoal() {
		int tempTotal;
		int totalVal=0;
		ArrayList<Integer> bcopy = new ArrayList<Integer>(vals);
		for(int p:nums){
			totalVal+=p;
		}
		totalVal=totalVal/numberTriads;
		
		
		for(int i=0; i<numberTriads; i++){
			tempTotal=0;

			for(int x=0; x<3; x++){
				if(Triad[((i*3)+x)]==0){
					tempTotal+=0;
				}
				else{
					tempTotal+=Triad[((i*3)+x)];
				}
			}
			if(tempTotal==totalVal){}
			else{
				return false;
			}	
		}
	

		for (int i = 1; i<numberTriads;i++){
			if(Triad[(3*i)-1]!=0 && (Triad[3*i]!=0)){
				if (bcopy.get(i-1)==Triad[(3*i)-1]+Triad[3*i]){
				}
				else {
					return false;
				}
			}
		}
		if (bcopy.get(bcopy.size()-1)==Triad[0]+Triad[Triad.length-1]){
			
		}
		else {
			return false;
		}
		return true;
	}
	/**
	 * toString in class java.lang.Object
	 */
	public String toString(){
		String s="";
		int c=0;
		System.out.println(vals);
		for(int x=1; x<=numberTriads; x++){
			for(int y=0; y<3; y++){
				s=s+Triad[c];
				if(y<2){
					s=s+".";
				}
				c++;
			}
			if(x<(numberTriads)){
				s=s+" - ";
			}
		}
		return s;
	}
}