/*
 * WheelConfig.java
 *
 * Version:
 * $Id: BackTracker.java,v 1.2 2014/10/29 06:05:59 sxp9646 Exp $
 *
 * Revisions:
 * $Log: BackTracker.java,v $
 * Revision 1.2  2014/10/29 06:05:59  sxp9646
 * *** empty log message ***
 *
 */

/**
 * This class represents the classic recursive backtracking algorithm.
 * It has a solver that can take a valid configuration and return a
 * solution, if one exists.
 * 
 * @author sps
 */
public class BackTracker {
    /*
     * Should debug output be enabled?
     */
    private boolean debug;
    
    /**
     * Initialize a new backtracker
     * 
     * @param debug Is debugging output enabled?
     */
    public BackTracker(boolean debug) {
        this.debug = debug;
        if (this.debug) {
            System.out.println("Backtracker debugging enabled...");
        }
    }
    
    /**
     * A utility routine for printing out various debug messages.
     * 
     * @param msg The type of config being looked at (current, goal, 
     *  successor, e.g.)
     * @param config The config to display
     */
    private void debugPrint(String msg, Configuration config) {
        if (this.debug) {
            System.out.println(msg + ": " + config);
        }
    }
    
    /**
     * Try find a solution, if one exists, for a given configuration.
     * 
     * @param config A valid configuration
     * @return A solution config, or null if no solution
     */
    public Configuration solve(Configuration config) {
        debugPrint("Current config", config);
        if (config.isGoal()) {
            debugPrint("Goal config", config);
            return config;
        } else {
            for (Configuration child : config.getSuccessors()) {
                if (child.isValid()) {
                    debugPrint("Valid successor", child);
                    Configuration sol = solve(child);
                    if (sol != null) {
                        return sol;
                    }
                } else {
                    debugPrint("Invalid successor", child);
                }
            }
            // implicit backtracking happens here
        } 
        return null;
    }
}